
/**
 * Filter alle Spiele auf der Website während inm Suchfeld ein Begriff eingegeben wird
 * 
 * To Dos:
 * - Suche alle Spiele aus HTML
 * - Suche das Suchfeld aus HTML
 * - Wenn in das Suchfeld etwas eingegeben wird, dann filtere alle Spiele
 * - Füge eine keyup Event Listener zum Suchfeld hinzu
 * - Wenn das Suchfeld leer ist, dann zeige alle Spiele an
 * 
 */
