
import { Player } from '../objects/Player.js';

export class Play extends Phaser.Scene {

    constructor() {
        super('play');
    }

    create() {
        let player = new Player(this, 100, 100, "Pink Man", 'Max');
        let player2 = new Player(this, 200, 100, "Ninja Frog", 'Max');
        let player3 = new Player(this, 300, 100, "Virtual Guy", 'Max');
        let player4 = new Player(this, 400, 100, "Mask Dude", 'Max');
        let player5 = new Player(this, 500, 100, "Mask Dude", 'Max');
        let player6 = new Player(this, 600, 100, "Mask Dude", 'Max');
    }

}